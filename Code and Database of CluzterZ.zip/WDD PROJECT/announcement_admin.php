<?php

$host = 'localhost'; 
$dbname = 'zora';
$username = 'root';
$password = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit;
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $created_at = date('Y-m-d H:i:s'); 


    $imageName = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $imageTmpName = $_FILES['image']['tmp_name'];
        $imageName = time() . '_' . $_FILES['image']['name']; 
        $imagePath = 'uploads/' . $imageName; 


        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif']; 
        if (in_array($_FILES['image']['type'], $allowedTypes)) {

            if (move_uploaded_file($imageTmpName, $imagePath)) {

            } else {
                echo "<script>alert('Gagal meng-upload gambar!');</script>";
            }
        } else {
            echo "<script>alert('Hanya file gambar yang diperbolehkan!');</script>";
        }
    }


    $sql = "INSERT INTO announcements (title, content, created_at, image) VALUES (?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$title, $content, $created_at, $imageName]);

    echo "<script>alert('Pengumuman berhasil ditambahkan!'); window.location.href = 'announcement_admin.php';</script>";
}


$sql = "SELECT * FROM announcements ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$announcements = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Pengumuman</title>
    <link rel="shortcut icon" href="Images Projek DWH/icon.png" />
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f5f5;
        }

        .container {
            margin-top: 50px;
        }

        .table-responsive {
            margin-top: 20px;
        }

        table {
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        th, td {
            text-align: center;
            padding: 12px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f7f7f7;
        }

        .btn {
            margin: 5px;
        }

        .navbar {
            margin-bottom: 40px;
        }

        .navbar-brand img {
            height: 72px;
        }

        .container-fluid {
            background-color: #0f0f0f;
        }

        footer {
            background-color: #0f0f0f;
            color: #fff;
            padding: 20px 0;
            margin-top: 20px;
        }

        footer a {
            color: #fff;
        }

        footer a:hover {
            text-decoration: none;
        }

        .footer-section {
            text-align: center;
        }

        .footer-section .col-md-2 {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="home_page_user.php">
                <img src="Images Projek DWH/logo.png" alt="Logo Zora">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="oi oi-menu"></span> Menu
            </button>

            <div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a href="home_page_admin.php" class="nav-link">Home</a></li>
                    <li class="nav-item active"><a href="announcement_admin.php" class="nav-link">Announcement</a></li>
                    <li class="nav-item"><a href="marketplace_admin.php" class="nav-link">Marketplace</a></li>
                    <li class="nav-item"><a href="resident_directory.php" class="nav-link">Resident Directory</a></li>
                    <li class="nav-item"><a href="feedback_admin.php" class="nav-link">Feedback</a></li>

                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="Images Projek DWH/iconuser.png" alt="User Icon" class="user-icon">
                        </a>
                        <div class="dropdown-menu" aria-labelledby="userDropdown">
                            <a href="login.php" class="dropdown-item">Logout</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <div class="container">
        <h2 class="text-center mb-4">Announcement History</h2>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Content</th>
                        <th>Date Posted</th>
                        <th>Image</th>
                    </tr>
                </thead>
                <tr>
                    <?php foreach ($announcements as $announcement): ?>
                        <tr>

                            <td><?php echo htmlspecialchars($announcement['title']); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($announcement['content'])); ?></td>
                            <td><?php echo $announcement['created_at']; ?></td>
                            <td>
                                <?php if ($announcement['image']): ?>
                                    <img src="uploads/<?php echo htmlspecialchars($announcement['image']); ?>" alt="Image" width="100">
                                <?php else: ?>
                                    No image
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tr>
            </table>
        </div>

        <h3 class="text-center mb-4">Add Announcement</h3>
        <form action="announcement_admin.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" id="title" name="title" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="content">Content</label>
                <textarea id="content" name="content" class="form-control" rows="5" required></textarea>
            </div>
            <div class="form-group">
                <label for="image">Image (optional)</label>
                <input type="file" id="image" name="image" class="form-control">
            </div>
            <button type="submit" name="submit" class="btn btn-primary mt-3">Add Announcement</button>
        </form>
    </div>


    <div class="container-fluid px-0">
        <footer>
            <div class="container py-5 footer-section">
                <section class="mt-3">
                    <div class="row text-center d-flex justify-content-center">
                        <div class="col-md-2 mb-3">
                            <h6 class="text-uppercase font-weight-bold">
                                <a href="home_page_admin.php" class="text-white">About us</a>
                            </h6>
                        </div>
                        <div class="col-md-2 mb-3">
                            <h6 class="text-uppercase font-weight-bold">
                                <a href="feedback_admin.php" class="text-white">Feedback</a>
                            </h6>
                        </div>
                    </div>
                </section>
            </div>
        </footer>
    </div>
</body>
</html>
