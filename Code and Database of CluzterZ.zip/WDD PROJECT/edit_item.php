
<?php
session_start();
include 'db_connect.php'; 


$product_id = $_GET['id'];
$user_id = $_SESSION['user_id']; 


$query = "SELECT * FROM products WHERE id = '$product_id' AND user_id = '$user_id'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    die("Anda tidak memiliki akses untuk mengedit produk ini.");
}

$row = mysqli_fetch_assoc($result);







if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "SELECT * FROM products WHERE id = $id";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $product = mysqli_fetch_assoc($result);
    } else {
        echo "Produk tidak ditemukan.";
        exit;
    }
} else {
    echo "ID produk tidak valid.";
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $price_raw = mysqli_real_escape_string($conn, $_POST['price']);
    $price_cleaned = str_replace(['Rp', '.', ' '], '', $price_raw);
    $price = floatval($price_cleaned);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $notelp = mysqli_real_escape_string($conn, $_POST['notelp']);
    $norek = mysqli_real_escape_string($conn, $_POST['norek']);


    $new_image_name = $product['image_url'];
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        $valid_extensions = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($image_extension, $valid_extensions)) {
            $new_image_name = uniqid('', true) . '.' . $image_extension;
            $upload_dir = 'uploads/';
            $image_path = $upload_dir . $new_image_name;

            if (move_uploaded_file($image_tmp, $image_path)) {

                if (!empty($product['image_url']) && file_exists($upload_dir . $product['image_url'])) {
                    unlink($upload_dir . $product['image_url']);
                }
            } else {
                echo "Gagal meng-upload gambar.";
                exit;
            }
        } else {
            echo "Ekstensi gambar tidak valid.";
            exit;
        }
    }


    $update_query = "UPDATE products SET 
        product_name = '$product_name', 
        price = '$price', 
        image_url = '$new_image_name', 
        nama = '$nama', 
        notelp = '$notelp', 
        norek = '$norek' 
        WHERE id = $id";

    if (mysqli_query($conn, $update_query)) {
        echo "Produk berhasil diperbarui.";
        header("Location: marketplace_user.php");
        exit;
    } else {
        echo "Gagal memperbarui produk: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Product</h2>
        <form action="edit_item.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="product_name" class="form-label">Product Name</label>
                <input type="text" class="form-control" id="product_name" name="product_name" value="<?php echo htmlspecialchars($product['product_name']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Price</label>
                <input type="text" class="form-control" id="price" name="price" value="Rp <?php echo number_format($product['price'], 0, ',', '.'); ?>" required oninput="formatRupiah(this)">
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Product Image (Leave empty to keep current)</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*">
            </div>
            <div class="mb-3">
                <label for="nama" class="form-label">Seller Name</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo htmlspecialchars($product['nama']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="notelp" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="notelp" name="notelp" value="<?php echo htmlspecialchars($product['notelp']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="norek" class="form-label">Bank Number</label>
                <input type="text" class="form-control" id="norek" name="norek" value="<?php echo htmlspecialchars($product['norek']); ?>" required>
            </div>

            <button type="submit" class="btn btn-success">Update</button>
            <a href="marketplace_user.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <script>
        function formatRupiah(input) {
            let value = input.value.replace(/[^,\d]/g, "");
            let split = value.split(",");
            let rupiah = split[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            input.value = "Rp " + rupiah + (split[1] !== undefined ? "," + split[1] : "");
        }
    </script>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>