
<?php
session_start();
include 'db_connect.php';


if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Anda harus login terlebih dahulu.'); window.location.href = 'login.php';</script>";
    exit();
}


$user_id = $_SESSION['user_id'];


$query = "SELECT * FROM products WHERE status = 'approved'";
$result = mysqli_query($conn, $query);
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace</title>
    <link rel="shortcut icon" href="Images Projek DWH/icon.png" />
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    .product-card {
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        padding: 15px;
        text-align: center;
        margin-bottom: 20px;
    }
    .product-image {
        max-width: 100%;
        height: auto;
        border-radius: 8px;
    }
    .chat-button {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 10px 15px;
        border-radius: 5px;
        cursor: pointer;
    }
    .chat-button:hover {
        background-color: #0056b3;
    }

    .seller-info {
        display: none;
        margin-top: 10px;
        background-color: #f8f9fa;
        padding: 15px;
        border-radius: 5px;
        border: 1px solid #ddd;
    }


    .chat-button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    text-align: center;
    display: inline-block;
    width: 100px;
}

.chat-button:hover {
    background-color: #0056b3;
}



</style>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="home_page_user.php">
                <img src="Images Projek DWH/logo1.png" alt="Logo Zora" style="height: 72px; width: auto;">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="oi oi-menu"></span> Menu
            </button>

            <div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a href="home_page_user.php" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="announcement_user.php" class="nav-link">Announcement</a></li>
                    <li class="nav-item active"><a href="marketplace_user.php" class="nav-link">Marketplace</a></li>
                    <li class="nav-item"><a href="feedback_process.php" class="nav-link">Feedback</a></li>
                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="Images Projek DWH/iconuser.png" alt="User Icon" class="user-icon">
                        </a>
                        <div class="dropdown-menu" aria-labelledby="userDropdown">
                            <a href="profile.php" class="dropdown-item">Profile</a>
                            <a href="login.php" class="dropdown-item">Logout</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="text-center">Market Place</h1>
        <div class="row row-cols-1 row-cols-md-5 g-4">
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
    <div class="col">
        <div class="product-card">
            <?php
            $image_url = 'uploads/' . $row['image_url'];
            ?>
            <img src="<?php echo htmlspecialchars($image_url); ?>" class="product-image" alt="<?php echo htmlspecialchars($row['product_name']); ?>">
            <h5 class="mt-3"><?php echo htmlspecialchars($row['product_name']); ?></h5>
            <p>Rp <?php echo number_format($row['price'], 0, ',', '.'); ?></p>

            <button class="chat-button" 
                    onclick="toggleSellerInfo(this, '<?php echo htmlspecialchars($row['nama']); ?>', '<?php echo htmlspecialchars($row['norek']); ?>', '<?php echo htmlspecialchars($row['notelp']); ?>')">
                    Detail
            </button>

            <?php if ($row['user_id'] == $_SESSION['user_id']): ?>
                <a href="edit_item.php?id=<?php echo $row['id']; ?>" class="chat-button">Edit</a>
            <?php endif; ?>


            <div class="seller-info">
                <p id="seller-name"></p>
                <p id="seller-norek"></p>
                <p id="seller-notelp"></p>
            </div>
        </div>
    </div>
<?php endwhile; ?>



        </div>
    </div>

    <div class="text-center mt-4">
        <p>Wanna Sell an Item?</p>
        <a href="sell_item.php" class="btn btn-primary">Click Here</a>
    </div>

    <script>
        function toggleSellerInfo(button, name, norek, notelp) {

            var sellerInfoDiv = button.closest('.product-card').querySelector('.seller-info');
            

            sellerInfoDiv.querySelector('#seller-name').innerText = 'Nama: ' + name;
            sellerInfoDiv.querySelector('#seller-norek').innerText = 'Nomor Rekening: ' + norek;
            sellerInfoDiv.querySelector('#seller-notelp').innerText = 'No. Telepon: ' + notelp;
            

            if (sellerInfoDiv.style.display === "none" || sellerInfoDiv.style.display === "") {
                sellerInfoDiv.style.display = "block";
                sellerInfoDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
            } else {
                sellerInfoDiv.style.display = "none";
            }
        }
    </script>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>