<?php

$host = 'localhost';  
$dbname = 'zora'; 
$username = 'root'; 
$password = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit;
}


$sql = "SELECT * FROM announcements ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$announcements = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Zora - Pengumuman</title>
    <link rel="shortcut icon" href="Images Projek DWH/icon.png" />
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f5f5;
        }

        .container {
            margin-top: 50px;
        }

        .announcement {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .announcement h3 {
            font-size: 1.8rem;
            font-weight: 600;
            color: #333;
        }

        .announcement p {
            font-size: 1rem;
            color: #555;
        }

        .announcement small {
            font-size: 0.9rem;
            color: #888;
        }

        .announcement hr {
            border-color: #eee;
        }

        .navbar {
            margin-bottom: 40px;
        }

        .navbar-brand img {
            height: 72px;
        }

        footer {
            background-color: #0f0f0f;
            color: #fff;
            padding: 20px 0;
            margin-top: 20px;
        }

        footer a {
            color: #fff;
        }

        footer a:hover {
            text-decoration: none;
        }

        .footer-section {
            text-align: center;
        }

        .footer-section .col-md-2 {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="home_page_user.php">
                <img src="Images Projek DWH/logo.png" alt="Logo Zora">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="oi oi-menu"></span> Menu
            </button>

            <div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a href="home_page_user.php" class="nav-link">Home</a></li>
                    <li class="nav-item active"><a href="announcement_user.php" class="nav-link">Announcement</a></li>
                    <li class="nav-item"><a href="marketplace_user.php" class="nav-link">Marketplace</a></li>
                    <li class="nav-item"><a href="feedback_process.php" class="nav-link">Feedback</a></li>
                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="Images Projek DWH/iconuser.png" alt="User Icon" class="user-icon">
                        </a>
                        <div class="dropdown-menu" aria-labelledby="userDropdown">
                        <a href="profile.php" class="dropdown-item">Profile</a>
                        <a href="login.php" class="dropdown-item">Logout</a>
                            
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <div class="container">
        <h2 class="text-center mb-4">Pengumuman Terbaru</h2>

        <?php if (count($announcements) > 0): ?>
            <?php foreach ($announcements as $announcement): ?>
                <div class="announcement">
                    <h3><?php echo htmlspecialchars($announcement['title']); ?></h3>
                    <p><?php echo nl2br(htmlspecialchars($announcement['content'])); ?></p>
                    <small>Dikirim pada: <?php echo $announcement['created_at']; ?></small>
                    
                    <?php if ($announcement['image']): ?>
                        <div class="image-container">
                            <img src="uploads/<?php echo htmlspecialchars($announcement['image']); ?>" alt="Image" style="max-width: 100%; height: auto; margin-top: 10px;">
                        </div>
                    <?php endif; ?>
                    <hr>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Tidak ada pengumuman saat ini.</p>
        <?php endif; ?>
    </div>


    <div class="container-fluid px-0">
        <footer>
            <div class="container py-5 footer-section">
                <section class="mt-3">
                    <div class="row text-center d-flex justify-content-center">
                        <div class="col-md-2 mb-3">
                            <h6 class="text-uppercase font-weight-bold">
                                <a href="home_page_user.php" class="text-white">About us</a>
                            </h6>
                        </div>
                        <div class="col-md-2 mb-3">
                            <h6 class="text-uppercase font-weight-bold">
                                <a href="feedback_process.php" class="text-white">Feedback</a>
                            </h6>
                        </div>
                        <div class="col-md-2 mb-3">
                            <h6 class="text-uppercase font-weight-bold">
                                <a href="#!" class="text-white">Help</a>
                            </h6>
                        </div>
                        <div class="col-md-2 mb-3">
                            <h6 class="text-uppercase font-weight-bold">
                                <a href="#!" class="text-white">Contact</a>
                            </h6>
                        </div>
                    </div>
                </section>
                <section class="mb-5">
                    <div class="row d-flex justify-content-center">
                        <div class="col-lg-8">
                            <p>
                                Kawasan perumahan Cluster Z BSD merupakan area hunian indah dan eksklusif dengan akses jalan dan fasilitas sekitar yang sangat baik.
                            </p>
                        </div>
                    </div>
                </section>
            </div>
            <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
                Cluster Z
                <a class="text-white" href="https://mdbootstrap.com/">| BSD City</a>
            </div>
        </footer>
    </div>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
