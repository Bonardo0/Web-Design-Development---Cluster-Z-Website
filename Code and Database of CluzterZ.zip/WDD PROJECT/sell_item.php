
<?php
session_start();
include 'db_connect.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id']; 

    $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $price_raw = mysqli_real_escape_string($conn, $_POST['price']);

    $price_cleaned = str_replace(['Rp', '.', ' '], '', $price_raw);

    $price = floatval($price_cleaned);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $notelp = mysqli_real_escape_string($conn, $_POST['notelp']);
    $norek = mysqli_real_escape_string($conn, $_POST['norek']);


    $image = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $image_size = $_FILES['image']['size'];
    $image_error = $_FILES['image']['error'];

    if ($image_error === 0) {

        $valid_extensions = ['jpg', 'jpeg', 'png', 'gif'];
        $image_extension = strtolower(pathinfo($image, PATHINFO_EXTENSION));

        if (in_array($image_extension, $valid_extensions)) {
            if ($image_size < 5000000) { 
                $new_image_name = uniqid('', true) . '.' . $image_extension;
                $upload_dir = 'uploads/'; 
                $image_path = $upload_dir . $new_image_name;

                if (move_uploaded_file($image_tmp, $image_path)) {

                    $query = "INSERT INTO products (product_name, price, image_url, nama, notelp, norek, user_id) 
                      VALUES ('$product_name', '$price', '$new_image_name', '$nama', '$notelp', '$norek', '$user_id')";

                    if (mysqli_query($conn, $query)) {
                        echo "Produk berhasil ditambahkan!";
                    } else {
                        echo "Gagal menyimpan produk: " . mysqli_error($conn);
                    }
                } else {
                    echo "Gagal meng-upload gambar.";
                }
            } else {
                echo "Ukuran gambar terlalu besar, maksimal 5MB.";
            }
        } else {
            echo "Ekstensi gambar tidak valid. Hanya jpg, jpeg, png, gif yang diperbolehkan.";
        }
    } else {
        echo "Terjadi kesalahan saat meng-upload gambar.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sell Item</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Sell Your Product</h2>
        <form action="sell_item.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="product_name" class="form-label">Product Name</label>
                <input type="text" class="form-control" id="product_name" name="product_name" required>
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Price</label>
                <input type="text" class="form-control" id="price" name="price" required oninput="formatRupiah(this)">
            </div>
            <div class="mb-3">
                <label for="image" class="form-label">Product Image</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
            </div>
            <div class="mb-3">
                <label for="nama" class="form-label">Seller Name</label>
                <input type="text" class="form-control" id="nama" name="nama" required>
            </div>
            <div class="mb-3">
                <label for="notelp" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="notelp" name="notelp" required>
            </div>
            <div class="mb-3">
                <label for="norek" class="form-label">Bank Number</label>
                <input type="text" class="form-control" id="norek" name="norek" required>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>


            <a href="marketplace_user.php" class="btn btn-secondary">Back to Marketplace</a>
        </form>
    </div>

    <script>

        function formatRupiah(input) {
            let value = input.value.replace(/[^,\d]/g, ""); 
            let split = value.split(",");
            let rupiah = split[0].replace(/\B(?=(\d{3})+(?!\d))/g, "."); 
            input.value = "Rp " + rupiah + (split[1] !== undefined ? "," + split[1] : ""); 
        }
    </script>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>