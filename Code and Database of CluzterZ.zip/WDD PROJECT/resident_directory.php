<?php
$conn = new mysqli('localhost', 'root', '', 'zora');

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}


if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $deleteQuery = "DELETE FROM users WHERE id = $id";

    if ($conn->query($deleteQuery) === TRUE) {
        echo "<script>alert('Data berhasil dihapus!'); window.location.href = 'resident_directory.php';</script>";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}


$sql = "SELECT * FROM users";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resident Directory</title>
    <link rel="shortcut icon" href="Images Projek DWH/icon.png" />
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">


    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
  </head>


    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }
        .container {
            margin-top: 50px;
        }
        table {
            background-color: white;
        }
        th, td {
            text-align: center;
        }
        .btn {
            margin: 2px;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">
        <a class="navbar-brand" href="home_page_user.php">
          <img src="Images Projek DWH/logo.png" alt="Logo Zora" style="height: 72px; width: auto;">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a href="home_page_admin.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="announcement_admin.php" class="nav-link">Announcement</a></li>
            <li class="nav-item"><a href="marketplace_admin.php" class="nav-link">Marketplace</a></li>
            <li class="nav-item active"><a href="resident_directory.php" class="nav-link">Resident Directory</a></li>
            <li class="nav-item"><a href="feedback_admin.php" class="nav-link">Feedback</a></li>
            

<li class="nav-item dropdown">
  <a href="#" class="nav-link dropdown-toggle" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <img src="Images Projek DWH/iconuser.png" alt="User Icon" class="user-icon">
  </a>
  <div class="dropdown-menu" aria-labelledby="userDropdown">

    <a href="login.php" class="dropdown-item">Logout</a>
  </div>
</li>
          </ul>
        </div>
      </div>
    </nav>

    

    <div class="container">
        <h2 class="text-center mb-4">Resident Directory</h2>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Unit</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['id']; ?></td>
                            <td><?= $row['name']; ?></td>
                            <td><?= $row['email']; ?></td>
                            <td><?= $row['unit']; ?></td>
                            <td>
                                <a href="edit_user.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="resident_directory.php?delete=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this record?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <a href="register_user.php" class="btn btn-primary">Add New Resident</a>
    </div>


<div class="container-fluid px-0">
  <footer class="text-center text-white" style="background-color: #0f0f0f; width: 100%; margin-top: 20px;">

    <div class="container py-5">

      <section class="mt-3">

        <div class="row text-center d-flex justify-content-center">

          <div class="col-md-2 mb-3">
            <h6 class="text-uppercase font-weight-bold">
              <a href="home_page_admin" class="text-white">About us</a>
            </h6>
          </div>



          <div class="col-md-2 mb-3">
            <h6 class="text-uppercase font-weight-bold">
              <a href="feedback_admin" class="text-white">Feedback</a>
            </h6>
          </div>



          <div class="col-md-2 mb-3">
            <h6 class="text-uppercase font-weight-bold">
              <a href="#!" class="text-white">Help</a>
            </h6>
          </div>



          <div class="col-md-2 mb-3">
            <h6 class="text-uppercase font-weight-bold">
              <a href="#!" class="text-white">Contact</a>
            </h6>
          </div>
   
        </div>

      </section>


      <hr class="my-5" />


      <section class="mb-5">
        <div class="row d-flex justify-content-center">
          <div class="col-lg-8">
            <p>
              Kawasan perumahan The Zora BSD merupakan area hunian indah dan eksklusif dengan akses jalan dan fasilitas sekitar yang sangat baik.
            </p>
          </div>
        </div>
      </section>




    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      The Zora
      <a class="text-white" href="https://mdbootstrap.com/">| BSD City</a>
    </div>

  </footer>
</div>




    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>


 <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


<script src="js/jquery.min.js"></script>
<script src="js/jquery-migrate-3.0.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/jquery.animateNumber.min.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/jquery.timepicker.min.js"></script>
<script src="js/scrollax.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
<script src="js/google-map.js"></script>
<script src="js/main.js"></script>

</body>
</html>
