<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Cluster Z - Beauty of Balance</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="Images Projek DWH/icon.png" />
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">


    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
        <a class="navbar-brand" href="home_page_admin.php">
          <img src="Images Projek DWH/logo1.png" alt="Logo Zora" style="height: 150px; width: auto;">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active"><a href="home_page_admin.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="announcement_admin.php" class="nav-link">Announcement</a></li>
            <li class="nav-item"><a href="marketplace_admin.php" class="nav-link">Marketplace</a></li>
            <li class="nav-item"><a href="resident_directory.php" class="nav-link">Resident Directory</a></li>
            <li class="nav-item"><a href="feedback_admin.php" class="nav-link">Feedback</a></li>
            

<li class="nav-item dropdown">
  <a href="#" class="nav-link dropdown-toggle" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <img src="Images Projek DWH/iconuser.png" alt="User Icon" class="user-icon">
  </a>
  <div class="dropdown-menu" aria-labelledby="userDropdown">

    <a href="login.php" class="dropdown-item">Logout</a>
  </div>
</li>
          </ul>
        </div>
      </div>
    </nav>

    
    <div class="hero-wrap" style="background-image: url('Images\ Projek\ DWH//homepage3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="overlay-2"></div>
      <div class="container">
        <div class="row no-gutters slider-text justify-content-center align-items-center">
          <div class="col-lg-8 col-md-6 ftco-animate d-flex align-items-end">
            <div class="text text-center w-100">
                <h1 class="mb-4" style="color: #f7f5f5; font-size: 48px; font-weight: bold; letter-spacing: 2px; text-transform: uppercase; line-height: 1.5; font-family: 'Playfair Display', serif;">
                    Cluster Z<br>Beauty of Balance
                </h1>
            </div>
        </div>
        </div>
        
        </div>
          </div>
        </div>
      </div>
      <div class="mouse">
				<a href="#" class="mouse-icon">
					<div class="mouse-wheel"><span class="ion-ios-arrow-round-down"></span></div>
				</a>
			</div>
    </div>



<div class="container-fluid px-0">
  <footer class="text-center text-white" style="background-color: #0f0f0f; width: 100%; margin-top: 20px;">

    <div class="container py-5">

      <section class="mt-3">

        <div class="row text-center d-flex justify-content-center">

          <div class="col-md-2 mb-3">
            <h6 class="text-uppercase font-weight-bold">
              <a href="announcement_admin.php" class="text-white">Announcement</a>
            </h6>
          </div>



          <div class="col-md-2 mb-3">
            <h6 class="text-uppercase font-weight-bold">
              <a href="#!" class="text-white">Marketplace</a>
            </h6>
          </div>



          <div class="col-md-2 mb-3">
            <h6 class="text-uppercase font-weight-bold">
              <a href="#!" class="text-white">Resident Directory</a>
            </h6>
          </div>


        </div>

      </section>


      <hr class="my-5" />


      <section class="mb-5">
        <div class="row d-flex justify-content-center">
          <div class="col-lg-8">
            <p>
              Kawasan perumahan Cluster Z  BSD merupakan area hunian indah dan eksklusif dengan akses jalan dan fasilitas sekitar yang sangat baik.
            </p>
          </div>
        </div>
      </section>




    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      Cluster Z
      <a class="text-white" href="https://mdbootstrap.com/">| BSD City</a>
    </div>

  </footer>
</div>



  


 <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


 <script src="js/jquery.min.js"></script>
 <script src="js/jquery-migrate-3.0.1.min.js"></script>
 <script src="js/popper.min.js"></script>
 <script src="js/bootstrap.min.js"></script>
 <script src="js/jquery.easing.1.3.js"></script>
 <script src="js/jquery.waypoints.min.js"></script>
 <script src="js/jquery.stellar.min.js"></script>
 <script src="js/owl.carousel.min.js"></script>
 <script src="js/jquery.magnific-popup.min.js"></script>
 <script src="js/aos.js"></script>
 <script src="js/jquery.animateNumber.min.js"></script>
 <script src="js/bootstrap-datepicker.js"></script>
 <script src="js/jquery.timepicker.min.js"></script>
 <script src="js/scrollax.min.js"></script>
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
 <script src="js/google-map.js"></script>
 <script src="js/main.js"></script>
   

</body>
</html>

    