<?php

$host = 'localhost';
$dbname = 'zora';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit;
}


$sql_feedback = "SELECT * FROM feedback ORDER BY created_at DESC";
$stmt_feedback = $pdo->prepare($sql_feedback);
$stmt_feedback->execute();
$feedbacks = $stmt_feedback->fetchAll();
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Pengumuman</title>
    <link rel="shortcut icon" href="Images Projek DWH/icon.png" />
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f5f5;
        }

        .container {
            margin-top: 50px;
        }

        .table-responsive {
            margin-top: 20px;
        }

        table {
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        th, td {
            text-align: center;
            padding: 12px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f7f7f7;
        }

        .btn {
            margin: 5px;
        }

        .navbar {
            margin-bottom: 40px;
        }

        .navbar-brand img {
            height: 72px;
        }

        .container-fluid {
            background-color: #0f0f0f;
        }

        footer {
            background-color: #0f0f0f;
            color: #fff;
            padding: 20px 0;
            margin-top: 20px;
        }

        footer a {
            color: #fff;
        }

        footer a:hover {
            text-decoration: none;
        }

        .footer-section {
            text-align: center;
        }

        .footer-section .col-md-2 {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="home_page_user.php">
                <img src="Images Projek DWH/logo.png" alt="Logo Zora">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="oi oi-menu"></span> Menu
            </button>

            <div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a href="home_page_admin.php" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="announcement_admin.php" class="nav-link">Announcement</a></li>
                    <li class="nav-item"><a href="marketplace_admin.php" class="nav-link">Marketplace</a></li>
                    <li class="nav-item"><a href="resident_directory.php" class="nav-link">Resident Directory</a></li>
                    <li class="nav-item active"><a href="feedback_admin.php" class="nav-link">Feedback</a></li>

                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="Images Projek DWH/iconuser.png" alt="User Icon" class="user-icon">
                        </a>
                        <div class="dropdown-menu" aria-labelledby="userDropdown">
                            <a href="login.php" class="dropdown-item">Logout</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h2 class="text-center mb-4">Feedback from User</h2>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Unit</th>
                        <th>Feedback</th>
                        <th>Date Posted</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($feedbacks as $feedback): ?>
                        <tr>
                            <td><?php echo $feedback['id']; ?></td>
                            <td><?php echo htmlspecialchars($feedback['name']); ?></td>
                            <td><?php echo htmlspecialchars($feedback['email']); ?></td>
                            <td><?php echo htmlspecialchars($feedback['unit']); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($feedback['message'])); ?></td>
                            <td><?php echo $feedback['created_at']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
