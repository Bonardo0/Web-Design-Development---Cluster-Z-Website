<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $unit = $_POST['unit'];
    $message = $_POST['message'];


    if (!empty($name) && !empty($email) && !empty($unit) && !empty($message)) {
        
        $sql = "INSERT INTO feedback (name, email, unit, message) VALUES ('$name', '$email', '$unit', '$message')";

        if ($conn->query($sql) === TRUE) {
            $feedback_success = "Feedback berhasil dikirim!";
        } else {
            $feedback_error = "Terjadi kesalahan: " . $conn->error;
        }
    } else {
        $feedback_error = "Semua field harus diisi!";
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Feedback</title>

  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    body {
      font-family: "Nunito", sans-serif;
      background-image: url('images Projek DWH/homepage.png');
      background-size: cover;
      background-position: center;
      height: 100vh;
      margin: 0;
    }
    .card {
      border-radius: 1rem;
      width: 60%;
      margin: auto;
    }
    .btn-dark {
      background-color: #393f81;
      border: none;
      width: 200px;
      height: 50px;
      font-size: 22px;
      text-align: center;
      display: block;
      margin: 20px auto;
    }
    .btn-dark:hover {
      background-color: #2e3169;
    }
    .form-label {
      font-weight: 700;
    }
    .logo-container {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-bottom: 20px;
    }
    .logo-container img {
      width: 250px;
      height: auto;
    }
    .message {
      text-align: center;
      font-size: 20px;
      margin-bottom: 20px;
    }
    .message-success {
      color: green;
    }
    .message-error {
      color: red;
    }
  </style>
</head>
<body>
  <section class="vh-100 d-flex justify-content-center align-items-center">
    <div class="card">
      <div class="row g-0">

        <form action="feedback_process.php" method="POST" class="p-4">
          
          <div class="logo-container">
          <a href="home_page_user.php">
            <img src="images Projek DWH/logo.png" alt="Logo">
          </a>
          </div>
          <h5 class="fw-normal mb-3 pb-3 text-center" style="letter-spacing: 1px; font-size: 28px;">Give Us Your Feedback</h5>


          <?php if (isset($feedback_success)) { ?>
            <div class="message message-success"><?php echo $feedback_success; ?></div>
          <?php } ?>
          <?php if (isset($feedback_error)) { ?>
            <div class="message message-error"><?php echo $feedback_error; ?></div>
          <?php } ?>

          
          <div class="form-outline mb-4">
            <label for="name" class="form-label">Name:</label>
            <input type="text" id="name" name="name" class="form-control form-control-lg" placeholder="Enter your name" required />
          </div>

          
          <div class="form-outline mb-4">
            <label for="email" class="form-label">Email:</label>
            <input type="email" id="email" name="email" class="form-control form-control-lg" placeholder="Enter your email" required />
          </div>

          
          <div class="form-outline mb-4">
            <label for="unit" class="form-label">No. Unit:</label>
            <input type="text" id="unit" name="unit" class="form-control form-control-lg" placeholder="Enter your unit number" required />
          </div>

          
          <div class="form-outline mb-4">
            <label for="message" class="form-label">Message:</label>
            <textarea id="message" name="message" class="form-control form-control-lg" rows="4" placeholder="Enter your message" required></textarea>
          </div>

          
          <button type="submit" class="btn btn-dark">Submit Feedback</button>
        </form>
      </div>
    </div>
  </section>

  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
