
<?php
session_start(); 
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = md5($_POST['password']); 


    $queryAdmin = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";
    $resultAdmin = $conn->query($queryAdmin);

    if ($resultAdmin->num_rows > 0) {
        header("Location: home_page_admin.php");
        exit();
    }


    $queryUser = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $resultUser = $conn->query($queryUser);

    if ($resultUser->num_rows > 0) {
        $user = $resultUser->fetch_assoc();


        $_SESSION['user_id'] = $user['id'];


        header("Location: home_page_user.php");
        exit();
    }


    echo "<script>alert('Email atau password salah!'); window.location.href = 'login.php';</script>";
}

$conn->close();
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    body {
      font-family: "Nunito", sans-serif;
      background-image: url('images Projek DWH/homepage.png');
      background-size: cover;
      background-position: center;
      height: 100vh;
      margin: 0;
    }
    .vh-100 {
      height: 100vh !important;
    }
    .card {
      border-radius: 1rem;
      width: 60%;
    }
    .btn-dark {
    background-color: #393f81;
    border: none;
    width: 200px; 
    height: 70px; 
    font-size: 30px; 
    display: flex;
    justify-content: center; 
    align-items: center; 
    text-align: center; 
    margin: 0 auto; 
}
    .btn-dark:hover {
      background-color: #2e3169;
    
    }
    .form-label {
      font-weight: 700;
    }

    .container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .card-body {
      width: 60%;
      max-width: 750px; 
      padding: 70px; 
    }
    .logo-container {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-bottom: 30px;
    }

    .logo-container img {
      width: 650px; 
      height: auto;
    }
  </style>
</head>
<body>
  <section class="vh-100">
    <div class="container">
      <div class="card">
        <div class="row g-0">

          <form action="login.php" method="POST">
          <div class="col-md-12 d-flex justify-content-center">
            <div class="card-body p-4 p-lg-5 text-black">
              <form id="loginForm">

                <div class="logo-container">
                  <img src="images Projek DWH/logo.png" alt="Logo">
                </div>

<h5 class="fw-normal mb-3 pb-3" style="letter-spacing: 1px; text-align: center; font-size: 28px;">Sign into your account</h5>

  <div class="form-outline mb-4">
    <input type="email" name="email" class="form-control form-control-lg" placeholder="Email address" style="font-size: 22px; padding: 35px;" required />
  </div>

  <div class="form-outline mb-4">
    <input type="password" name="password" class="form-control form-control-lg" placeholder="Password" style="font-size: 22px; padding: 35px;" required />
  </div>

<div class="pt-1 mb-4" style="text-align: center;">
  <button class="btn btn-dark" type="submit">Login</button>
  <a href="register_user.php;">
  </a>
</div>
</form>


                <div style="text-align: center;">
                <a class="small text-muted" href="#!">Forgot password?</a>
                </div>
                <p class="mb-5 pb-lg-2" style="color: #393f81; text-align: center;">Don't have an account? <a href="register_user.php"
                    style="color: #393f81;">Register here</a></p>
                    <div style="text-align: center;">
                      <a href="#!" class="small text-muted" style="color: #393f81; margin: 0 10px;">Terms of use.</a>
                      <a href="#!" class="small text-muted" style="color: #393f81; margin: 0 10px;">Privacy policy</a>
                  </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Bootstrap JS -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
  <script>
    document.getElementById('loginForm').addEventListener('submit', function(event) {
      event.preventDefault(); // Prevent default form submission
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;

      console.log('Email:', email);
      console.log('Password:', password);


    });
  </script>
</body>
</html>