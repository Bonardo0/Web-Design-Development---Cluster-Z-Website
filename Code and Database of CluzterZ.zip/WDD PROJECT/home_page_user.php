<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Cluster Z - Beauty of Balance</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="Images Projek DWH/icon.png" />
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">


    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  </head>
  <body>
    
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
  <div class="container">
    <a class="navbar-brand" href="home_page_user.php">
      <img src="Images Projek DWH/logo1.png" alt="Logo Zora" style="height: 150px; width: auto;">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="oi oi-menu"></span> Menu
    </button>

    <div class="collapse navbar-collapse" id="ftco-nav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active"><a href="home_page_user.php" class="nav-link">Home</a></li>
        <li class="nav-item"><a href="announcement_user.php" class="nav-link">Announcement</a></li>
        <li class="nav-item"><a href="marketplace_user.php" class="nav-link">Marketplace</a></li>
        <li class="nav-item"><a href="feedback_process.php" class="nav-link">Feedback</a></li>
        

        <li class="nav-item dropdown">
          <a href="#" class="nav-link dropdown-toggle" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="Images Projek DWH/iconuser.png" alt="User Icon" class="user-icon">
          </a>
          <div class="dropdown-menu" aria-labelledby="userDropdown">

            <a href="profile.php" class="dropdown-item">Profile</a>
            <a href="login.php" class="dropdown-item">Logout</a>
          </div>
        </li>
      </ul>
    </div>
  </div>
</nav>

    
    <div class="hero-wrap" style="background-image: url('Images\ Projek\ DWH//homepage3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="overlay-2"></div>
      <div class="container">
        <div class="row no-gutters slider-text justify-content-center align-items-center">
          <div class="col-lg-8 col-md-6 ftco-animate d-flex align-items-end">
            <div class="text text-center w-100">
                <h1 class="mb-4" style="color: #f7f5f5; font-size: 48px; font-weight: bold; letter-spacing: 2px; text-transform: uppercase; line-height: 1.5; font-family: 'Playfair Display', serif;">
                    Cluster Z  <br>Beauty of Balance
                </h1>
            </div>
        </div>
        </div>
        
        </div>
          </div>
        </div>
      </div>
      <div class="mouse">
				<a href="#" class="mouse-icon">
					<div class="mouse-wheel"><span class="ion-ios-arrow-round-down"></span></div>
				</a>
			</div>
    </div>

<section class="ftco-section ftco-no-pb">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="search-wrap-1 ftco-animate">

          <div class="map-title" style="text-align: center;">
            <h3>Our Location</h3>
          </div>

          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.873877669036!2d106.62609067518511!3d-6.280306993708555!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f521aa4a72a9%3A0x87cbebe57f917f49!2sThe%20Zora%20BSD%20City!5e0!3m2!1sid!2sid!4v1732684788126!5m2!1sid!2sid" 
            width="100%" height="500" style="border:0; margin-bottom: 50px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
          </iframe>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="about-us-section" id="about-us">
  <div class="container">
    <h2 class="text-center mb-5">About Us</h2>

    <div class="row">
       <div class="col-md-6 mb-4">
        <div class="card">
        <img src="Images Projek DWH/cluster3.png" class="card-img-top" alt="cluster3">
        <div class="card-body text-center">
        <h5 class="card-title">Cluster 3</h5>
      </div>
    </div>
  </div>
  <div class="col-md-6 mb-4">
    <div class="card">
      <img src="Images Projek DWH/cluster4.jpeg" class="card-img-top" alt="cluster4">
      <div class="card-body text-center">
        <h5 class="card-title">Cluster 4</h5>
      </div>
    </div>
  </div>
</div>

<div class="text-center mt-5">
      <p>
      Cluster Z BSD hadir menyajikan pilihan terbaik hunian bergaya Jepang authentic yang tak hanya bernuansa romantic,
      tapi juga sangat kokoh. Kompleks rumah di BSD ini dibangun dengan desain dan kualitas yang ditujukan untuk 3 generasi keluarga.
      Berlokasi di kawasan yang super strategi...
      </p>
    </div>
  </div>
</br>
</br>
</br>
</br>
</br>
  

    <h2 class="text-center mb-5">Fasilitas Cluster Z </h2>
    <div class="row">

      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="Images Projek DWH/area_bermain.jpg" class="card-img-top" alt="Area Bermain">
          <div class="card-body text-center">
            <h5 class="card-title">Area Bermain</h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="Images Projek DWH/club_house.jpg" class="card-img-top" alt="Club House">
          <div class="card-body text-center">
            <h5 class="card-title">Club House</h5>
          </div>
        </div>
      </div>

      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="Images Projek DWH/lobby.jpg" class="card-img-top" alt="Eksklusif Lobi">
          <div class="card-body text-center">
            <h5 class="card-title">Eksklusif Lobi</h5>
          </div>
        </div>
      </div>
    </div>

    <div class="text-center mt-5">
      <p>
      Memiliki luas lahan 19 hektare, Cluster Z BSD dilengkapi beragam fasilitas penunjang. 
      Desain inspirasi Jepang dapat dilihat juga pada fasilitasnya, seperti pada gerbang cluster dan Japanese bridge. 
      Lingkungannya hijau dengan 5 taman tematik yakni Ohana, Nami, Hanabi, Hoshi, dan Kizuna Garden. 
      Fasilitas olahraga dan relaksasi dapat Anda temukan di Samasana Club House, 
      lengkap dengan Japanese aquamassage, kolam onsen, kolam renang, dan coffee lounge.
      </p>
    </div>
  </div>
</section>

<style>
  .about-us-section {
    padding: 60px 0;
    background-color: #f9f9f9;
  }
  .about-us-section h2 {
    font-size: 36px;
    font-weight: bold;
    margin-bottom: 30px;
    color: #333;
  }
  .card {
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border: none;
  }
  .card img {
    border-radius: 8px;
  }
  .card-title {
    font-size: 18px;
    font-weight: 600;
    margin-top: 15px;
    color: #555;
  }
  .about-us-section p {
    font-size: 16px;
    color: #666;
    line-height: 1.8;
    max-width: 800px;
    margin: 0 auto;
  }
</style>



<div class="container-fluid px-0">
  <footer class="text-center text-white" style="background-color: #0f0f0f; width: 100%; margin-top: 20px;">

    <div class="container py-5">

      <section class="mt-3">

        <div class="row text-center d-flex justify-content-center">

          <div class="col-md-2 mb-3">
            <h6 class="text-uppercase font-weight-bold">
              <a href="home_page_user.php" class="text-white">About us</a>
            </h6>
          </div>



          <div class="col-md-2 mb-3">
            <h6 class="text-uppercase font-weight-bold">
              <a href="feedback_process.php" class="text-white">Feedback</a>
            </h6>
          </div>



          <div class="col-md-2 mb-3">
            <h6 class="text-uppercase font-weight-bold">
              <a href="#!" class="text-white">Help</a>
            </h6>
          </div>



          <div class="col-md-2 mb-3">
            <h6 class="text-uppercase font-weight-bold">
              <a href="#!" class="text-white">Contact</a>
            </h6>
          </div>

        </div>

      </section>


      <hr class="my-5" />


      <section class="mb-5">
        <div class="row d-flex justify-content-center">
          <div class="col-lg-8">
            <p>
              Kawasan perumahan Cluster Z BSD merupakan area hunian indah dan eksklusif dengan akses jalan dan fasilitas sekitar yang sangat baik.
            </p>
          </div>
        </div>
      </section>




    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      Cluster Z
      <a class="text-white" href="https://mdbootstrap.com/">| BSD City</a>
    </div>

  </footer>
</div>



  

 <!-- loader -->
 <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


 <script src="js/jquery.min.js"></script>
 <script src="js/jquery-migrate-3.0.1.min.js"></script>
 <script src="js/popper.min.js"></script>
 <script src="js/bootstrap.min.js"></script>
 <script src="js/jquery.easing.1.3.js"></script>
 <script src="js/jquery.waypoints.min.js"></script>
 <script src="js/jquery.stellar.min.js"></script>
 <script src="js/owl.carousel.min.js"></script>
 <script src="js/jquery.magnific-popup.min.js"></script>
 <script src="js/aos.js"></script>
 <script src="js/jquery.animateNumber.min.js"></script>
 <script src="js/bootstrap-datepicker.js"></script>
 <script src="js/jquery.timepicker.min.js"></script>
 <script src="js/scrollax.min.js"></script>
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
 <script src="js/google-map.js"></script>
 <script src="js/main.js"></script>
   

</body>
</html>

    