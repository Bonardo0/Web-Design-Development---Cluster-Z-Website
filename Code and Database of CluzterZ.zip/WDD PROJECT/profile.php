<?php
session_start();
require 'db_connect.php'; 


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id']; 


$query = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($query);


if ($stmt === false) {
    die('Error preparing statement: ' . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();


if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc(); 
} else {
   
    echo "User not found!";
    exit();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $notelp = $_POST['notelp'];


    if (empty($name) || empty($email) || empty($notelp)) {
        $error_message = "All fields are required!";
    } else {

        $update_query = "UPDATE users SET name = ?, email = ?, notelp = ? WHERE id = ?";
        $stmt = $conn->prepare($update_query);
        

        if ($stmt === false) {
            die('Error preparing update statement: ' . $conn->error);
        }

        $stmt->bind_param("sssi", $name, $email, $notelp, $user_id);

        if ($stmt->execute()) {

            $success_message = "Profile updated successfully!";
            $stmt->close();  


            $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
            if ($stmt === false) {
                die('Error preparing statement for fetching updated data: ' . $conn->error);
            }
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();


            if ($result && $result->num_rows > 0) {
                $user = $result->fetch_assoc(); 
            } else {
                $error_message = "Error fetching updated profile data!";
            }
        } else {
            $error_message = "Error updating profile!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace</title>
    <link rel="shortcut icon" href="Images Projek DWH/icon.png" />
    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
    .product-card {
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        padding: 15px;
        text-align: center;
        margin-bottom: 20px;
    }
    .product-image {
        max-width: 100%;
        height: auto;
        border-radius: 8px;
    }
    .chat-button {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 10px 15px;
        border-radius: 5px;
        cursor: pointer;
    }
    .chat-button:hover {
        background-color: #0056b3;
    }

    .seller-info {
        display: none;
        margin-top: 10px;
        background-color: #f8f9fa;
        padding: 15px;
        border-radius: 5px;
        border: 1px solid #ddd;
    }


    .chat-button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    text-align: center;
    display: inline-block;
    width: 100px;
}

.chat-button:hover {
    background-color: #0056b3;
}



</style>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="home_page_user.php">
                <img src="Images Projek DWH/logo1.png" alt="Logo Zora" style="height: 72px; width: auto;">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="oi oi-menu"></span> Menu
            </button>

            <div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a href="home_page_user.php" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="announcement_user.php" class="nav-link">Announcement</a></li>
                    <li class="nav-item"><a href="marketplace_user.php" class="nav-link">Marketplace</a></li>
                    <li class="nav-item"><a href="feedback_process.php" class="nav-link">Feedback</a></li>
                    <li class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" id="userDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="Images Projek DWH/iconuser.png" alt="User Icon" class="user-icon">
                        </a>
                        <div class="dropdown-menu" aria-labelledby="userDropdown">
                            <a href="profile.php" class="dropdown-item">Profile</a>
                            <a href="login.php" class="dropdown-item">Logout</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <div class="container profile-container">
        <h2>Your Profile</h2>

        <?php if (isset($success_message)): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php elseif (isset($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required <?php echo isset($_GET['edit']) ? '' : 'disabled'; ?>>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required <?php echo isset($_GET['edit']) ? '' : 'disabled'; ?>>
            </div>
            <div class="mb-3">
                <label for="notelp" class="form-label">Phone</label>
                <input type="text" class="form-control" id="notelp" name="notelp" value="<?php echo htmlspecialchars($user['notelp']); ?>" required <?php echo isset($_GET['edit']) ? '' : 'disabled'; ?>>
            </div>


            <?php if (isset($_GET['edit'])): ?>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            <?php endif; ?>

            <a href="profile.php<?php echo isset($_GET['edit']) ? '' : '?edit=true'; ?>" class="btn btn-secondary">
                <?php echo isset($_GET['edit']) ? 'Cancel' : 'Edit Profile'; ?>
            </a>
        </form>
    </div>

    <footer class="text-center text-white" style="background-color: #0f0f0f; margin-top: 40px;">
        <div class="container py-5">
            <section>
                <div class="row text-center d-flex justify-content-center">
                    <div class="col-md-2 mb-3">
                        <h6 class="text-uppercase font-weight-bold">
                            <a href="home_page_user.php" class="text-white">About us</a>
                        </h6>
                    </div>
                    <div class="col-md-2 mb-3">
                        <h6 class="text-uppercase font-weight-bold">
                            <a href="feedback_process.php" class="text-white">Feedback</a>
                        </h6>
                    </div>
                </div>
            </section>
        </div>
        <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            Cluster Z | BSD City
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
