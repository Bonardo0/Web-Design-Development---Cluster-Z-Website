<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = md5($_POST['password']); 
    $unit = $_POST['unit'];
    $notelp = $_POST['notelp'];


    echo "Nomor Telepon Diterima dari Form: " . $_POST['notelp'] . "<br>";


    if (strpos($notelp, '+62') !== 0) {
        $notelp = '+62' . ltrim($notelp, '0'); 
    }
    

    echo "Nomor Telepon Setelah Ditambah +62: " . $notelp . "<br>";

  


    $checkEmailQuery = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($checkEmailQuery);

    if ($result->num_rows > 0) {
      echo "<script>alert('Email sudah terdaftar! Silakan gunakan email lain.'); window.location.href = 'register_user.php';</script>";
  } else {

      $insertQuery = "INSERT INTO users (name, email, password, unit, notelp) VALUES ('$name', '$email', '$password', '$unit', '$notelp')";


      echo "Query yang Dieksekusi: " . $insertQuery . "<br>";

      if ($conn->query($insertQuery) === TRUE) {
          echo "<script>alert('Registrasi berhasil!'); window.location.href = 'login.php';</script>";
      } else {

          echo "Error pada Query INSERT: " . $conn->error;
      }
  }
}


$conn->close();
?>






<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register</title>

  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    body {
      font-family: "Nunito", sans-serif;
      background-image: url('images Projek DWH/homepage.png'); 
      background-size: cover;
      background-position: center;
      height: 100vh;
      margin: 0;
    }
    .vh-100 {
      height: 100vh !important;
    }
    .card {
      border-radius: 1rem;
      width: 100%;
    }
    .btn-dark {
      background-color: #393f81;
      border: none;
    }
    .btn-dark:hover {
      background-color: #2e3169;
    }
    .form-label {
      font-weight: 700;
    }

    .container {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .card-body {
      width: 100%;
      max-width: 750px; 
      padding: 70px; 
    }
    .logo-container {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-bottom: 30px;
    }

    .logo-container img {
      width: 650px;
      height: auto;
    }
  </style>
</head>
<body>
  <section class="vh-100">
    <div class="container">
      <div class="card">
        <div class="row g-0">
       
          <form action="register_user.php" method="POST">
          <div class="col-md-12 d-flex justify-content-center">
            <div class="card-body p-4 p-lg-5 text-black">
              <form id="loginForm">
    
                <div class="logo-container">
                  <img src="images Projek DWH/logo.png" alt="Logo">
                </div>

<h5 class="fw-normal mb-3 pb-3" style="letter-spacing: 1px; text-align: center; font-size: 28px;">Register your account</h5>


  <div class="form-outline mb-4">
    <input type="text" name="name" class="form-control form-control-lg" placeholder="Name" required />
  </div>

  <div class="form-outline mb-4">
    <input type="email" name="email" class="form-control form-control-lg" placeholder="Email address" required />
  </div>

  <div class="form-outline mb-4">
    <input type="password" name="password" class="form-control form-control-lg" placeholder="Password" required />
  </div>

  <div class="form-outline mb-4">
    <input type="text" name="unit" class="form-control form-control-lg" placeholder="Unit" required />
  </div>

  <div class="form-outline mb-4">
    <input type="text" name="notelp" class="form-control form-control-lg" placeholder="Nomor telepon (contoh: 81234567890)" required />
  </div>


  <div class="pt-1 mb-4" style="text-align: center;">
    <button class="btn btn-dark" type="submit">Register</button>
  </div>
</form>




                <p class="mb-5 pb-lg-2" style="color: #393f81; text-align: center;">Already Have an Account? <a href="login.php"
                    style="color: #393f81;">Login Here</a></p>
                <a href="#!" class="small text-muted">Terms of use.</a>
                <a href="#!" class="small text-muted">Privacy policy</a>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
  <script>
    document.getElementById('registerForm').addEventListener('submit', function(event) {
      event.preventDefault(); 
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const unit = document.getElementById('unit').value;
      const password = document.getElementById('password').value;

      console.log('Name:', name);
      console.log('Email:', email);
      console.log('Unit:', unit);
      console.log('Password:', password);

    });
  </script>
</body>
</html>
