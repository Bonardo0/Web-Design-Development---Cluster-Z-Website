<?php
session_start();
include 'db_connect.php'; 

if (isset($_GET['id'])) {
    $id = $_GET['id'];


    $query = "UPDATE products SET status = 'approved' WHERE id = $id";
    if (mysqli_query($conn, $query)) {

        header("Location: marketplace_admin.php");
        exit();
    } else {
        echo "Error updating product: " . mysqli_error($conn);
    }
}
?>
