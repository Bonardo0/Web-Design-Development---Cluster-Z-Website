<?php
session_start();
include 'db_connect.php';


if (isset($_GET['id']) && isset($_GET['status'])) {
    $productId = $_GET['id'];
    $status = $_GET['status'];


    if ($status == 'approved' || $status == 'rejected') {

        $query = "UPDATE products SET status = '$status' WHERE id = $productId";
        if (mysqli_query($conn, $query)) {

            header('Location: marketplace_admin.php');
            exit();
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Invalid status value.";
    }
} else {
    echo "Missing product ID or status.";
}
?>
